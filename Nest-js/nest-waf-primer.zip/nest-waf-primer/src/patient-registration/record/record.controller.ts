import { Controller, Get, Post, Body, Put, Param, Delete, Render } from '@nestjs/common';
import { RecordService } from './record.service'; // Changed PatientService to RecordService
import { CreateRecordDto } from './dto/create-record.dto'; // Changed CreatePatientDto to CreateRecordDto
import { UpdateRecordDto } from './dto/update-record.dto'; // Changed UpdatePatientDto to UpdateRecordDto

@Controller('record') // Changed 'patient' to 'record'
export class RecordController { // Changed PatientController to RecordController
  
  constructor(private readonly recordService: RecordService) {} // Changed patientService to recordService
  

  @Get('create') // Changed 'create' to 'create'
  @Render('record/create-record.html') // Changed 'patient/create-patient.html' to 'record/create-record.html'
  createForm() {
  }
  
  @Post() // Changed 'patient' to 'record'
  create(@Body() createRecordDto: CreateRecordDto) { // Changed createPatientDto to createRecordDto
    return this.recordService.create(createRecordDto); // Changed patientService to recordService
  }

  @Get() // Changed 'patient' to 'record'
  findAll() {
    return this.recordService.findAll(); // Changed patientService to recordService
  }

  @Get(':id') // Changed 'patient' to 'record', id to :id
  findOne(@Param('id') id: number) {
    return this.recordService.findOne(+id); // Changed patientService to recordService
  }

  @Put(':id') // Changed 'patient' to 'record', id to :id
  update(@Param('id') id: number, @Body() updateRecordDto: UpdateRecordDto) { // Changed updatePatientDto to updateRecordDto
    return this.recordService.update(id, updateRecordDto); // Changed patientService to recordService
  }

  @Delete(':id') // Changed 'patient' to 'record', id to :id
  remove(@Param('id') id: number) {
    return this.recordService.remove(+id); // Changed patientService to recordService
  }
}
