import { Module } from '@nestjs/common';
import { RecordService } from './record.service'; // Changed PatientService to RecordService
import { RecordController } from './record.controller'; // Changed PatientController to RecordController
import { TypeOrmModule } from '@nestjs/typeorm';
import { Record } from './entities/record.entity'; // Changed Patient to Record
import { Patient } from '../patient/entities/patient.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Record, Patient])], // Changed Patient to Record
  controllers: [RecordController], // Changed PatientController to RecordController
  providers: [RecordService], // Changed PatientService to RecordService
})
export class RecordModule {} // Changed PatientModule to RecordModule
