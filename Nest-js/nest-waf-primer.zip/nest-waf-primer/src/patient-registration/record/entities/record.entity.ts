//import { ModeOfEntry } from "../../../patient-registration/patientRegistration.types";
import { Column, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { Patient } from "../../../patient-registration/patient/entities/patient.entity";

@Entity()
export class Record {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({nullable: true})
    MAT_no: string;
    
    @Column({nullable: true})
    ClinicDate: Date;

    @Column({nullable: true})
    NatureOfAilment: string;

    @Column({nullable: true})
    MedicinePrescribed: string;

    @Column({nullable: true})
    procedure: string;

    @Column({nullable: true})
    DateOfNextApt: Date;

    @JoinColumn()
    @OneToOne(type => Patient, patient => patient.record, {cascade:true})
    patient: Patient;
}
