import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Patient } from '../patient/entities/patient.entity'; // Changed User to Patient
import { CreateRecordDto } from './dto/create-record.dto'; // Changed CreateStudentDto to CreateRecordDto
import { UpdateRecordDto } from './dto/update-record.dto'; // Changed UpdateStudentDto to UpdateRecordDto
import { Record } from './entities/record.entity'; // Changed Student to Record

@Injectable()
export class RecordService {

  constructor(
    @InjectRepository(Record) // Changed Student to Record
    private recordRepository: Repository<Record>, // Changed studentRepository to recordRepository

    @InjectRepository(Patient) // Changed User to Patient
    private patientRepository: Repository<Patient> // Changed userRepository to patientRepository
  ) { }

  async create(createRecordDto: CreateRecordDto) {
    // return 'This action adds a new student'; // Updated comment to reflect Record instead of student
    const newRecord = this.recordRepository.create(createRecordDto);
    // ideally, below should be wrapped in a transaction so that it can roll back if there is error in any of the stages.
    if (createRecordDto.patient) { // Changed user to patient
      const newPatient = this.patientRepository.create(createRecordDto.patient); // Changed newUser to newPatient
      const patient: Patient = await this.patientRepository.save(newPatient); // Changed user to patient
      newRecord.patient = patient; // Changed user to patient
    }
    return this.recordRepository.save(newRecord); // Changed studentRepository to recordRepository
  }

  async findAll() {
    // return `This action returns all students`; // Updated comment to reflect Record instead of student
    return await this.recordRepository.find({ relations: ['patient'] }); // Changed studentRepository to recordRepository and user to patient
  }

  async findOne(id: number) {
    // return `This action returns a #${id} student`; // Updated comment to reflect Record instead of student
    return await this.recordRepository.findOne({
      where: {
        id
      },
      relations: ['patient'] // Changed studentRepository to recordRepository and user to patient
    });
  }

  async update(id: number, updateRecordDto: UpdateRecordDto) {
    // return `This action updates a #${id} student`; // Updated comment to reflect Record instead of student
    return await this.recordRepository.update(id, updateRecordDto); // Changed studentRepository to recordRepository
  }

  async remove(id: number) {
    // return `This action removes a #${id} student`; // Updated comment to reflect Record instead of student
    return await this.recordRepository.delete(id); // Changed studentRepository to recordRepository
  }

  /* Work on relationships */
  async setPatientById(recordId: number, patientId: number) { // Changed setUserById to setPatientById and userId to patientId
    try {
      return await this.recordRepository.createQueryBuilder()
        .relation(Record, "patient") // Changed Student to Record
        .of(recordId)
        .set(patientId); // Changed userId to patientId
    } catch (error) {
      throw new HttpException({
        status: HttpStatus.INTERNAL_SERVER_ERROR,
        error: `There was a problem setting patient for record: ${error.message}`,
      }, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async unsetPatientById(recordId: number) { // Changed unsetUserById to unsetPatientById
    try {
      return await this.recordRepository.createQueryBuilder()
        .relation(Record, "patient") // Changed Student to Record
        .of(recordId)
        .set(null);
    } catch (error) {
      throw new HttpException({
        status: HttpStatus.INTERNAL_SERVER_ERROR,
        error: `There was a problem unsetting patient for record: ${error.message}`,
      }, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
}
