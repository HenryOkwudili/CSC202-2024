import { CreatePatientDto } from "../../../patient-registration/patient/dto/create-patient.dto";
//import { ModeOfEntry } from "../../../patient-registration/patientRegistration.types";

export class CreateRecordDto {

    readonly MAT_no: string;
    readonly ClinicDate: Date;
    readonly NatureOfAilment: string;
    readonly MedicinePrescribed: string;
    readonly procedure: string;
    readonly DateOfNextApt: Date;
    readonly patient: CreatePatientDto; //In case you want to create a patient along with record

}
