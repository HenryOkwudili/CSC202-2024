export class CreatePatientDto {
    readonly MAT_no: string;
    readonly firstName: string;
    readonly middleName?: string;
    readonly lastName: string;
    readonly dateOfBirth?: Date;
    readonly HOME_address?: string;
    readonly dateOfReg?: Date;
    readonly isActive?: boolean;
}