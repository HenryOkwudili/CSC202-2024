import { Record } from "../../../patient-registration/record/entities/record.entity";
import { Column, Entity, OneToOne, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Patient {

    @PrimaryGeneratedColumn()
    id: number;
    
    @Column({nullable: true})
    MAT_no: string;

    @Column()
    firstName: string;

    @Column({nullable: true})
    middleName: string;

    @Column()
    lastName: string;

    @Column({nullable: true})
    dateOfBirth: Date;

    @Column({nullable: true})
    dateOfReg: Date;

    @Column({nullable: true})
    HOME_address: string;

    @OneToOne(type => Record, record => record.patient)
    record: Record;

}