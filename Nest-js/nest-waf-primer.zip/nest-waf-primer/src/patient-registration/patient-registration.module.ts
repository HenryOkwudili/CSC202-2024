import { Module } from '@nestjs/common';
import { PatientModule } from './patient/patient.module';
import { RecordModule } from './record/record.module';

@Module({
  imports: [PatientModule, RecordModule]
})
export class PatientRegistrationModule {}
