import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { StudentRegistrationModule } from './student-registration/student-registration.module';
import { PatientRegistrationModule } from './patient-registration/patient-registration.module';

@Module({
  imports: [TypeOrmModule.forRoot({
    type: "postgres",
    host: "localhost",
    port: 5432,
    username: "postgres",
    password: "Iamherlix424567",
    database: "nestwafprimer",
    entities: [
        "dist/**/*.entity{.ts,.js}"
    ],
    synchronize: true
}), StudentRegistrationModule, PatientRegistrationModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}